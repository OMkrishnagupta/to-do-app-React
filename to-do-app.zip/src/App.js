import { useState } from "react";
import "./styles.css";

export default function App() {
  const [todos,setTodos] = useState([]);
  const [newTask,setNewtask]=useState('');
  const [editIndex, setEditIndex] = useState(-1);
  const todo = ()=>{
    if(newTask.trim()!=''){
      setTodos([...todos, newTask]);
      setNewtask('');
    }
  }
  const deleteTodo=(index)=>{
    const newTodo = todos.filter((_,i)=>i!==index);
    setTodos(newTodo);
  }
  const editTodo = (event) => {
    
    if (newTask.trim() !== '') {
      if (editIndex === -1) {
        setTasks([...todos, newTask]);
      } else {
        const editedTodo = prompt('Edit the todo:'); 
        const updatedTasks = [...todos];
        updatedTasks[editIndex] = editedTodo;
        setTodos(updatedTasks);
        setEditIndex(-1);
      }
      setNewTask('');
    }
  }

  return (
    <div className="App">
      <div style={{ color: "magenta" }}>
        <h1>To-Do List</h1>
        <h2>let's get started</h2>
      </div>
      <input
        style={{
          width: 300,
          height: 30,
          border: "3px solid magenta",
          color: "black",
        }}
        
        value={newTask}
      onChange={(e)=>setNewtask(e.target.value)}
        type="text"
        placeholder="Enter text"
      />
      
      <br />
      <AddButton />
      <br/>
        
      <br />
      <br />
      <ul>
          {todos.map((todo,index)=>(
            <>
            <li key={index}>{<Tasks value={todo}/>}</li>
            <div>
            <button onClick={()=>deleteTodo(index)}>Delete</button>
            <button onClick={()=>editTodo(index)}>Edit</button>
             </div></>
          ))}
        </ul>
      

    </div>
  );
  function Tasks({ value, deleteTask, editTask,index }) {
    return (
      <div
        style={{
          height: 30,
          width: 300,
          justifyContent: "space-between",
          display: "flex",
          alignItems: "center",
        }}
      >
        <div>
         {value}
        </div>
       
      </div>
    );
  }
  function AddButton(){
    return(<>
      <button onClick={todo}>ADD</button>
      </>
    );
  }
}
